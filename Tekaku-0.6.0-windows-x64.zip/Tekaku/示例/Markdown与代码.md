# Markdown 与代码

从一句想法，到一段清晰的代码。文字、表格和代码，在同一页自然排版。

## Python 示例

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"

print(greet("Tekaku"))
```

## 一份简单的清单

- [x] 记录想法，整理标题
- [x] 插入代码，选择语言
- [ ] 按 Ctrl+S 保存到自己的电脑

| 编辑方式 | 用途 |
| --- | --- |
| 快捷输入与 / 菜单 | 自然地写作 |
| 侧栏插入 | 找到所有常用内容 |
| Markdown 源码 | 精确修改原文 |

## C++ 示例

```cpp
#include <iostream>

int main() {
  std::cout << "Hello, Tekaku!" << std::endl;
  return 0;
}
```

## 包含代码围栏的例子

````markdown
```js
console.log("围栏作为代码原文保留");
```
````
